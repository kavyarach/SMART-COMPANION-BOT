from groq import Groq
import requests
import random
import sys

from config import GROQ_API_KEY, OPENWEATHER_API_KEY

client = Groq(api_key=GROQ_API_KEY)

WEATHER_BASE_URL = "http://api.openweathermap.org/data/2.5/weather"


# ================== AI RESPONSE ==================
def get_ai_response(user_message):
    try:
        response = client.chat.completions.create(
            model="llama-3.3-70b-versatile",
            messages=[
                {
                    "role": "system",
                    "content": (
                        "You are Smart Companion Bot, a friendly, helpful AI assistant. "
                        "Reply naturally, casually, and keep answers concise unless asked otherwise."
                    )
                },
                {
                    "role": "user",
                    "content": user_message
                }
            ],
            temperature=0.7,
            max_tokens=500
        )

        return response.choices[0].message.content

    except Exception as e:
        print(f"Groq API Error: {e}", file=sys.stderr)
        return "Macha, something went wrong 😅"


# ================== EMOJIFY ==================
def emojize(text):

    emoji_map = {
        "hello": "👋",
        "great": "👍",
        "goodbye": "👋",
        "happy": "😊",
        "sad": "😔",
        "love": "❤️",
        "thanks": "🙏",
        "bye": "👋",
        "weather": "🌤",
        "miss you": "🥲",
        "congratulations": "🎉",
        "kiss": "😘"
    }

    lower_text = text.lower()

    for word, emoji in emoji_map.items():
        if word in lower_text:
            text += f" {emoji}"

    if "sun" in lower_text or "clear" in lower_text:
        text += " ☀️"

    if "rain" in lower_text:
        text += " 🌧️"

    if "cloud" in lower_text:
        text += " ☁️"

    if "storm" in lower_text:
        text += " ⛈️"

    endings = ["🔥", "😎", "🙌", "😁", "😂", "✨", "🥲"]

    text += " " + random.choice(endings)

    return text


# ================== WEATHER ==================
def get_weather(city_name):

    try:

        params = {
            "q": city_name,
            "appid": OPENWEATHER_API_KEY,
            "units": "metric"
        }

        response = requests.get(WEATHER_BASE_URL, params=params)

        data = response.json()

        if data.get("cod") == 200:

            temp = data["main"]["temp"]
            description = data["weather"][0]["description"]
            humidity = data["main"]["humidity"]
            wind = data["wind"]["speed"]

            return (
                f"The weather in {city_name.title()} is {description}.\n"
                f"🌡 Temp: {temp}°C | 💧 Humidity: {humidity}% | 🌬 Wind: {wind} m/s"
            )

        else:
            return f"Macha, I couldn't find weather for {city_name} 😅"

    except requests.exceptions.RequestException as e:
        print(f"Weather API Error: {e}", file=sys.stderr)
        return "Weather fetch failed macha 🚨"


# ================== CHAT LOOP ==================
def start_conversation():

    print("Bot: Yo macha! 😁 I'm your Smart Companion Bot. Ask me anything! Type 'bye' to exit.")

    while True:

        try:

            user_input = input("You: ")

            if user_input.lower().strip() == "bye":
                print("Bot: Catch you later macha! 👋🔥")
                break

            elif user_input.lower().startswith("weather in "):

                city = user_input.replace("weather in ", "").strip()

                print("Bot: Checking weather... ⏳")

                bot_response = get_weather(city)

            else:

                print("Bot: Thinking... 🤔")

                bot_response = get_ai_response(user_input)

            bot_response = emojize(bot_response)

            print("Bot:", bot_response)

        except (EOFError, KeyboardInterrupt):

            print("\nBot: Bye macha 👋")
            sys.exit()


if __name__ == "__main__":
    start_conversation()