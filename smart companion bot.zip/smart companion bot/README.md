# 🤖 Smart Companion Bot

A Python chatbot powered by the Groq API using the Llama 3.3 70B model.

It provides:

- AI-powered conversations
- Real-time weather updates
- Friendly "macha" style replies
- Emoji-enhanced responses

---

## Features

- Conversational AI
- Real-time weather
- Emoji support
- Easy to customize

---

## Installation

```bash
git clone https://github.com/yourusername/smart-companion-bot.git
```

```bash
cd smart-companion-bot
```

```bash
pip install -r requirements.txt
```

---

## Run

```bash
python main.py
```

---

## Commands

Chat normally

```
Hello
```

Weather

```
weather in Hyderabad
```

Exit

```
bye
```

---

## Technologies

- Python
- Groq API
- OpenWeather API
- Requests